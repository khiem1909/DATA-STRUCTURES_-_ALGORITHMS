import java.util.ArrayList;
import java.util.LinkedList;

public class StudentManagementSystem {

    // Original ArrayList
    private ArrayList<Student> students = new ArrayList<>();
    // Optimized LinkedList
    private LinkedList<Student> students = new LinkedList<>();

    
    public void addStudent(String id, String name, double marks) throws IllegalArgumentException {
        validateStudent(id, name, marks);
        students.add(new Student(id, name, marks));
        System.out.println("Student added successfully.");

    }

public void editStudent(String id, String name, double marks) {
    boolean hasErrors = false;
    if (name == null || name.trim().isEmpty()) {
        System.out.println("Name cannot be null or empty.");
        hasErrors = true;
    }
    if (marks < 0 || marks > 10) {
        System.out.println("Marks must be between 0 and 10.");
        hasErrors = true;
    }
    if (hasErrors) {
        return;
    }

    for (Student student : students) {
        if (student.getId().equals(id)) {
            student.setName(name);
            student.setMarks(marks);
            System.out.println("Edit successfully.");
            return;

        }
    }
    System.out.println("Student with ID " + id + " not found.");

}

    public void deleteStudent(String id) throws IllegalArgumentException {
        boolean removed = students.removeIf(student -> student.getId().equals(id));
        System.out.println("Delete successfully.");
        if (!removed) {
            throw new IllegalArgumentException("Student with ID " + id + " not found.");
        }

    }

    private void validateStudent(String id, String name, double marks) throws IllegalArgumentException {
        if (id == null || id.trim().isEmpty()) {
            throw new IllegalArgumentException("ID cannot be null or empty.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty.");
        }
        if (marks < 0 || marks > 10) {
            throw new IllegalArgumentException("Marks must be between 0 and 10.");
        }
    }

    public void mergeSortStudents() {
        students = mergeSort(students);
    }

    private ArrayList<Student> mergeSort(ArrayList<Student> list) {
        if (list.size() <= 1) {
            return list;
        }
        int mid = list.size() / 2;
        ArrayList<Student> left = new ArrayList<>(list.subList(0, mid));
        ArrayList<Student> right = new ArrayList<>(list.subList(mid, list.size()));
        return merge(mergeSort(left), mergeSort(right));
    }


    private ArrayList<Student> merge(ArrayList<Student> left, ArrayList<Student> right) {
        ArrayList<Student> result = new ArrayList<>();
        int leftIndex = 0, rightIndex = 0;


        while (leftIndex < left.size() && rightIndex < right.size()) {
            if (left.get(leftIndex).getMarks() > right.get(rightIndex).getMarks()) {
                result.add(left.get(leftIndex++));
            } else {
                result.add(right.get(rightIndex++));
            }
        }


        while (leftIndex < left.size()) {
            result.add(left.get(leftIndex++));
        }
        while (rightIndex < right.size()) {
            result.add(right.get(rightIndex++));
        }


        return result;
    }

    public Student searchStudent(String id) throws IllegalArgumentException {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                return student;
            }
        }
        throw new IllegalArgumentException("Student with ID " + id + " not found.");
    }

    public void displayStudents() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }
}
