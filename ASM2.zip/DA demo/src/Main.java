import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentManagementSystem sms = new StudentManagementSystem();

        boolean running = true;
        while (running) {
            try {
                System.out.println("Choose an option: Add, Edit, Delete, Sort, Search, Display, Exit");
                String choice = scanner.nextLine();

                switch (choice.toLowerCase()) {
                    case "add":
                        System.out.println("Enter ID:");
                        String id = scanner.nextLine().trim();
                        System.out.println("Enter name:");
                        String name = scanner.nextLine().trim();
                        System.out.println("Enter marks:");
                        double marks = scanner.nextDouble();
                        scanner.nextLine();
                        sms.addStudent(id, name, marks);
                        break;
                    case "edit":
                        System.out.println("Enter ID of student to edit:");
                        id = scanner.nextLine().trim();
                        System.out.println("Enter new name:");
                        name = scanner.nextLine().trim();
                        System.out.println("Enter new marks:");
                        marks = scanner.nextDouble();
                        scanner.nextLine();
                        sms.editStudent(id, name, marks);
                        break;
                    case "delete":
                        System.out.println("Enter ID of student to delete:");
                        id = scanner.nextLine().trim();
                        sms.deleteStudent(id);
                        break;

                    case "sort":
                        sms.mergeSortStudents();

                        break;
                    case "search":
                        System.out.println("Enter ID of student to search:");
                        id = scanner.nextLine().trim();
                        Student student = sms.searchStudent(id);
                        if (student != null) {
                            System.out.println(student);
                        } else {
                            System.out.println("Student not found.");
                        }
                        break;
                    case "display":
                        sms.displayStudents();
                        break;
                    case "exit":
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter correct data types.");
                scanner.nextLine();
            } catch (IllegalArgumentException e) {
                System.out.println("Error: " + e.getMessage());
            } catch (Exception e) {
                System.out.println("An unexpected error occurred: " + e.getMessage());
            }
        }

        scanner.close();
    }
}
