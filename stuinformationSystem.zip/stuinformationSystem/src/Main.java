import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        StudentManagementSystem sms = new StudentManagementSystem();

        boolean running = true;
        while (running) {
            System.out.println("Choose an option: Add, Edit, Delete, Sort, Search, Display, Exit");
            String choice = scanner.nextLine();

            switch (choice.toLowerCase()) {
                case "add":
                    System.out.println("Enter ID:");
                    String id = scanner.nextLine();
                    System.out.println("Enter name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter marks:");
                    double marks = scanner.nextDouble();
                    scanner.nextLine();  // Consume newline
                    sms.addStudent(id, name, marks);
                    break;
                case "edit":
                    System.out.println("Enter ID of student to edit:");
                    id = scanner.nextLine();
                    System.out.println("Enter new name:");
                    name = scanner.nextLine();
                    System.out.println("Enter new marks:");
                    marks = scanner.nextDouble();
                    scanner.nextLine();  // Consume newline
                    sms.editStudent(id, name, marks);
                    break;
                case "delete":
                    System.out.println("Enter ID of student to delete:");
                    id = scanner.nextLine();
                    sms.deleteStudent(id);
                    break;
                case "sort":
                    sms.sortStudents();
                    break;
                case "search":
                    System.out.println("Enter ID of student to search:");
                    id = scanner.nextLine();
                    Student student = sms.searchStudent(id);
                    if (student != null) {
                        System.out.println(student);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;
                case "display":
                    sms.displayStudents();
                    break;
                case "exit":
                    running = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }

        scanner.close();
    }
}
