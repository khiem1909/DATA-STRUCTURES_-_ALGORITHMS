import java.util.ArrayList;

public class StudentManagementSystem {
    private ArrayList<Student> students = new ArrayList<>();

    public void addStudent(String id, String name, double marks) {
        students.add(new Student(id, name, marks));
    }

    public void editStudent(String id, String name, double marks) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                student.setName(name);
                student.setMarks(marks);
                return;
            }
        }
        System.out.println("Student with ID " + id + " not found.");
    }

    public void deleteStudent(String id) {
        students.removeIf(student -> student.getId().equals(id));
    }

    public void sortStudents() {
        int n = students.size();
        for (int i = 0; i < n - 1; i++) {
            int maxIdx = i;
            for (int j = i + 1; j < n; j++) {
                if (students.get(j).getMarks() > students.get(maxIdx).getMarks()) {
                    maxIdx = j;
                }
            }
            Student temp = students.get(maxIdx);
            students.set(maxIdx, students.get(i));
            students.set(i, temp);
        }
    }

    public Student searchStudent(String id) {
        for (Student student : students) {
            if (student.getId().equals(id)) {
                return student;
            }
        }
        return null;
    }

    public void displayStudents() {
        if (students.isEmpty()) {
            System.out.println("No students to display.");
        } else {
            for (Student student : students) {
                System.out.println(student);
            }
        }
    }
}
